<?php
/*
===================================
� Copyright 2007-2013 � webgility Inc. all rights reserved.
----------------------------------------
This file and the source code contained herein are the property of Webgility LLC
and are protected by United States copyright law. All usage is restricted as per 
the terms & conditions of Webgility License Agreement. You may not alter or remove 
any trademark, copyright or other notice from copies of the content.

The code contained herein may not be reproduced, copied, modified or redistributed in any form
without the express written consent by an officer of Webgility LLC.
===================================
*/

$wg_config_last_updated_date = '16 May 2012';    
$storeMduleVersion = "312";
$eCCDesktopCompitableVersion = "v3.0 - 3.9";
$eCCMobileCompitableVersion = "1.5";
$cartCompitableVersion = "Community Edition 1.2.1 to 1.8.0.1, Enterprise Edition 1.7.1 to 1.13.0.2";


#Setting
$RewardsPoints_Name = 'RewardsPoints';
$set_capture_case=false;
$set_Special_Price=false;
$set_Short_Description=false;
$display_discount_desc = true; // set false if client wants to display coupon  code instead of description
$Set_ReorderPoint=false; 
$get_Active_Carriers=false;	
$cart_name_upgrade= "magento";
?>