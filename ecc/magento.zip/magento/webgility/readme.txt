eCC Service Module Installation Guidelines 

-------------------------------------------------------------------------------------------------------------------------------------------  
Installing the Magneto module (For Magento users) 
-------------------------------------------------------------------------------------------------------------------------------------------    

 Please refer following in URL for further information http://support.webgility.com/ecc/index.html?installing_ecc_on_magento_ftp.htm
